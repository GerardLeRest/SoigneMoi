DROP TABLE IF EXISTS Sejours;
DROP TABLE IF EXISTS Prescription;
DROP TABLE IF EXISTS Avis;
DROP TABLE IF EXISTS Patients;
DROP TABLE IF EXISTS Entrees_Sorties;
DROP TABLE IF EXISTS Medecins;

CREATE TABLE Medecins(
    matricule Int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    prenom Varchar(50) NOT NULL,
    nom Varchar(50) NOT NULL,
    specialite Varchar(50) NOT NULL,
    date Date NOT NULL,
    nombre_patients Int NOT NULL
);

CREATE TABLE Avis(
    idAvis Int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    libelle Varchar (50) NOT NULL,
    description Text NOT NULL,
    matricule Int NOT NULL,
    FOREIGN KEY (matricule) REFERENCES Medecins(matricule)
);

CREATE TABLE Entrees_Sorties(
    idEntreeSortie Int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sortie_du_jour Date NOT NULL,
    entree_du_jour Date NOT NULL
);

CREATE TABLE Patients(
    idPatient Int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    prenom Varchar (255) NOT NULL,
    nom Varchar (50) NOT NULL,
    adresse_postale Varchar (50) NOT NULL,
    email Varchar (255) NOT NULL,
    mot_de_passe Varchar (50) NOT NULL,
    date_admission Date NOT NULL,  -- Changé le type de Int à Date pour date_admission
    date_sortie Date NOT NULL,
    idEntreeSortie Int NOT NULL,
    matricule Int NOT NULL,
    FOREIGN KEY (idEntreeSortie) REFERENCES Entrees_Sorties(idEntreeSortie),
    FOREIGN KEY (matricule) REFERENCES Medecins(matricule)
);

CREATE TABLE Sejours(
    IDSejour Int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    date_debut Date NOT NULL,
    date_fin Date NOT NULL,
    motif_sejour Text NOT NULL,
    specialite Varchar (50) NOT NULL,
    medecin_souhaite Varchar (50) NOT NULL,
    idPatient Int NOT NULL,
    FOREIGN KEY (idPatient) REFERENCES Patients(idPatient)
);

CREATE TABLE Prescription(
    idPrescription Int NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nom_medicament Varchar (100) NOT NULL,
    posologie Int NOT NULL,
    date_de_debut Date NOT NULL,
    date_defin Date NOT NULL,
    matricule Int NOT NULL,
    FOREIGN KEY (matricule) REFERENCES Medecins(matricule)
);