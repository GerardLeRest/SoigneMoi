<!doctype html>
<html lang="fr">

    <?php require_once('commun/head.php') ?>
    
    <body class="d-flex flex-column min-vh-100">

        <?php require_once('commun/header.php'); ?>
        
        <main class="container flex-grow-1">
            <form action="/formulairePatient" method="post"> <!-- /slim-secretariat-web/formulairePatient : route -->
                <div class ="row text-center">
                    <div class="col-12">
                        <br>
                        <br>
                        <h4> Inscription</h4>
                        <br>
                    </div>
                </div>
                <br>
                <br>
                <div class ="row justify-content-center">
                    <!--prenom-->
                    <div class="mb-2 col-lg-4 col-sm-6 col-xs-12 ">
                        <label for="prenom" class="form-label">Prénom</label>
                        <input type="text" class="form-control" id="prenom" name ="prenom" required>
                    </div>
                    <!--nom-->
                    <div class="mb-2 col-lg-4 col-sm-6 col-xs-12">
                        <label for="nom" class="form-label">Nom</label>
                        <input type="text" class="form-control" id="nom" name="nom" required>
                    </div>
                </div>
                <!--adressepostale-->
                <div class="mb-2 col-lg-10 offset-lg-2 col-sm-12 col-xs-12">
                    <label for="adressePostale" class="form-label">Adresse Postale</label>
                    <input type="text" class="form-control" id="adressePostale" name="adressePostale" required>
                </div>
                <!--adresse email-->
                <div class="mb-2 col-lg-5 offset-lg-2 col-sm-8 col-xs-12">
                    <label for="email" class="form-label">Adresse Email</label>
                    <input type="email" class="form-control" id="email" name="email" required placeholder="prenom.nom@exemple.fr">
                </div>
                <!--mot de passe-->
                <div class="mb-2 col-lg-5 offset-lg-2 col-sm-8 col-xs-12">
                    <label for="motDePasse" class="form-label">Password</label>
                    <input type="password" id="motDePasse" class="form-control" aria-describedby="passwordHelpBlock" name="motDePasse" required>
                    <div id="motDePasse" class="form-text">
                        Le mot de passe doit contenir entre 8 et 20 caractères, incluant au moins une lettre minuscule, une lettre majuscule, un chiffre, et un caractère spécial.
                    </div>
                </div>    
                <br>
                <!--bouton "Valider"-->
                <div class="col-12 text-center">
                    <button type="submit" class="btn bouton-perso">Valider</button>
                </div>
            </form>
      
            <!-- endroit où vont s'afficher les erreurs -->
            <ul id="erreur-list"></ul>
          
            <!-- initialisation $erreur s'il n'est pas défini -->
            <?php $erreurs = isset($erreurs) ? $erreurs : []; ?>
        
        </main> 

        <!-- pied de page -->
        <?php require_once('commun/footer.php'); ?>
        
        <!-- Appel du fichier afficherErreurs.js -->
        <script src="public/assets/js/afficherErreurs.js"></script>

        <script>
            // Injection du tableau JSON dans une variable JavaScript
            const erreursDeValidation = <?php echo json_encode($erreurs); ?>;
            // appel de la fonction afficherErreurs
            afficherErreurs(erreursDeValidation);
        </script>

    </body>
</html>
